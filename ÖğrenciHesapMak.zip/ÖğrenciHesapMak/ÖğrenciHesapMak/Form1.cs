﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ÖğrenciHesapMak
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            string ogrenciAdi = textBox1.Text;

            double vize, odev, proje, final;

            if (!double.TryParse(textBox2.Text, out vize) ||
               !double.TryParse(textBox3.Text, out odev) ||
               !double.TryParse(textBox4.Text, out proje) ||
                !double.TryParse(textBox5.Text, out final))
            {
                MessageBox.Show("Lütfen Geçerli Notlar Girin.");
                return;
            }


            double agirlikliortalama = (vize * 0.40) + (odev * 0.10) + (proje * 0.20) + (final * 0.30);

            double gecmenotu = agirlikliortalama >= 60 ? 60 : agirlikliortalama;

            string harfnotu = GetHarfNotu(agirlikliortalama);

            string sonuc = agirlikliortalama >= 60 ? "Geçti" : "Kaldı";

            //öğrencinin adını ve notunu listboxlara ekleme
            listBox1.Items.Add(ogrenciAdi);
            listBox2.Items.Add(vize);
            listBox3.Items.Add(odev);
            listBox4.Items.Add(proje);
            listBox5.Items.Add(final);
            listBox6.Items.Add(agirlikliortalama.ToString("0.00"));
            listBox7.Items.Add(harfnotu);

            //Ortalama güncelleme
            UpdateAverages();

            //Textboxları temizleme
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();

        }

        private string GetHarfNotu (double agirlikliortalama)
        {
            if (agirlikliortalama >= 90)
                return "AA";
            else if (agirlikliortalama >= 85)
                return "BA";
            else if (agirlikliortalama >= 80)
                return "BB";
            else if (agirlikliortalama >= 75)
                return "CB";
            else if (agirlikliortalama >= 70)
                return "CC";
            else if (agirlikliortalama >= 60)
                return "DC";
            else if (agirlikliortalama >= 50)
                return "DD";
            else if (agirlikliortalama >= 40)
                return "FD";
            else
                return "FF";


        }


        private void UpdateAverages()
        {
            double vizetoplam = 0, odevtoplam = 0, projetoplam = 0, finaltoplam = 0;
            int ogrencisayisi = listBox1.Items.Count;

            for (int i = 0; i < ogrencisayisi; i++)
            {
                vizetoplam += Convert.ToDouble(listBox2.Items[i]);
                odevtoplam += Convert.ToDouble(listBox3.Items[i]);
                projetoplam += Convert.ToDouble(listBox4.Items[i]);
                finaltoplam += Convert.ToDouble(listBox5.Items[i]);
            }

            label7.Text = (vizetoplam / ogrencisayisi).ToString("0.00");
            label8.Text = (odevtoplam / ogrencisayisi).ToString("0.00");
            label9.Text = (projetoplam / ogrencisayisi).ToString("0.00");
            label10.Text = (finaltoplam / ogrencisayisi).ToString("0.00");

            double gecmenotutoplam = 0;
            for (int i = 0; i < ogrencisayisi; i++)
            {
                gecmenotutoplam += Convert.ToDouble(listBox6.Items[i]);

            }
            label11.Text = (gecmenotutoplam / ogrencisayisi).ToString("0.00");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;

            if (selectedIndex != -1)
            {
                listBox1.Items.RemoveAt(selectedIndex);
                listBox2.Items.RemoveAt(selectedIndex);
                listBox3.Items.RemoveAt(selectedIndex);
                listBox4.Items.RemoveAt(selectedIndex);
                listBox5.Items.RemoveAt(selectedIndex);
                listBox6.Items.RemoveAt(selectedIndex);
                listBox7.Items.RemoveAt(selectedIndex);



                UpdateAverages();
            }
            else
            {
                MessageBox.Show("Lütfen bir öğrenci seçin.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            listBox7.Items.Clear();



            label7.Text = "0.00";
            label8.Text = "0.00";
            label9.Text = "0.00";
            label10.Text = "0.00";
            label11.Text = "0.00";


            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }


  
    }





